<!-- footer.php -->
<footer class="footer mt-auto py-3 bg-primary text-center text-white">
    <div class="container">
        <span> Authors: Mohamed Abdinasir & Kpenabari Taoh CSCI-371 ©<?= date("Y"); ?></span>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
