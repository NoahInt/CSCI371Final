<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Path to autoload.php in PHPMailer

// Create a new PHPMailer instance
$mail = new PHPMailer();

// SMTP configuration
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'csci371DogAdoption@gmail.com';
$mail->Password = 'wncx kpjc npgy nqul';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

// Email content
$mail->setFrom('ilovepuppies2@gmail.com', 'Your Name');
$mail->addAddress('recipient@example.com');
$mail->Subject = 'Your subject';
$mail->Body = 'Your message body';

// Send email
if (!$mail->send()) {
    echo 'Error: ' . $mail->ErrorInfo;
} else {
    echo 'Email sent successfully!';
}
?>
