<?php
session_start();
require 'db.php';  // Include your database connection

// Redirect if not logged in or if the user is not an admin.
if (!isset($_SESSION['loggedin']) || $_SESSION['userType'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Handle form submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect post data and sanitize
    $dogName = $conn->real_escape_string($_POST['name']);
    $dogBreed = $conn->real_escape_string($_POST['breed']);
    $dogSex = $conn->real_escape_string($_POST['sex']);
    $dogAge = $conn->real_escape_string($_POST['age']);
    $dogColor = $conn->real_escape_string($_POST['color']);
    $dogSize = $conn->real_escape_string($_POST['size']);
    $dogDescription = $conn->real_escape_string($_POST['description']);
    $dogMedical = $conn->real_escape_string($_POST['medical']);

    // Prepare an insert statement
    $sql = "INSERT INTO Dogtable (DogName, DogBreed, DogSex, DogAge, DogColor, DogSize, DogDescription, DogMedical) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    if ($stmt = $conn->prepare($sql)) {
        // Bind variables to the prepared statement as parameters
        $stmt->bind_param("sssissss", $dogName, $dogBreed, $dogSex, $dogAge, $dogColor, $dogSize, $dogDescription, $dogMedical);
        
        // Attempt to execute the prepared statement
        if ($stmt->execute()) {
            $message = "Dog added successfully.";
        } else {
            $message = "Error: " . $stmt->error;
        }
        
        // Close statement
        $stmt->close();
    } else {
        $message = "Error preparing statement: " . $conn->error;
    }
    
    // Close connection
    $conn->close();
}

// Include the header
include 'admin_header.php';
?>

<div class="container mt-4">
    <h1>Add a New Dog</h1>
    <?php if ($message): ?>
        <div class="alert <?= strpos($message, 'successfully') ? 'alert-success' : 'alert-danger' ?>">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <form action="admin-add-dog.php" method="post">
        <div class="mb-3 row">
            <div class="col">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="col">
                <label for="breed" class="form-label">Breed</label>
                <input type="text" class="form-control" id="breed" name="breed" required>
            </div>
        </div>

        <div class="mb-3 row">
            <div class="col">
                <label for="sex" class="form-label">Sex</label>
                <select class="form-select" id="sex" name="sex" required>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div class="col">
                <label for="age" class="form-label">Age</label>
                <input type="text" class="form-control" id="age" name="age" required>
            </div>
        </div>

        <div class="mb-3 row">
            <div class="col">
                <label for="color" class="form-label">Color</label>
                <input type="text" class="form-control" id="color" name="color" required>
            </div>
            <div class="col">
                <label for="size" class="form-label">Size</label>
                <input type="text" class="form-control" id="size" name="size" required>
            </div>
        </div>

        <div class="mb-3">
            <label for="medical" class="form-label">Medical</label>
            <input type="text" class="form-control" id="medical" name="medical" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" id="description" name="description" rows="7" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Add Dog</button>
        <button type="reset" class="btn btn-secondary btn-block">Reset</button>
    </form>
</div>

<?php
include 'footer.php';
?>
