<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

require_once 'db.php'; // Database connection file
require_once 'header.php'; // Include the header

// Fetch available dogs
$dogs = mysqli_query($conn, "SELECT DogID, DogName FROM Dogtable");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = $_SESSION['userID']; // Get user ID from session
    $dogId = $_POST['dogId']; // Get dog ID from form
    $historyNote = $_POST['historyNote'];
    $annualIncome = $_POST['annualIncome'];
    $numOfPets = $_POST['numPets'];
    $hadPastPets = isset($_POST['hadPastPets']) ? $_POST['hadPastPets'] : '';
    $hadDog = isset($_POST['hadDog']) ? $_POST['hadDog'] : '';

    // Update user data in the database if changed
    mysqli_query($conn, "UPDATE UserTable SET annualIncome = $annualIncome, numOfPets = $numOfPets WHERE UserID = $userId");

    $sql = "INSERT INTO History (AdoptionDate, HistoryNote, Dogtable_DogID, UserTable_UserID, HadPastPets, HadDog) VALUES (NOW(), ?, ?, ?, ?, ?)";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("siiii", $historyNote, $dogId, $userId, $hadPastPets, $hadDog);
        $stmt->execute();
        $stmt->close();
        echo "<p>Request submitted successfully.</p>";
    } else {
        echo "<p>Error: " . $conn->error . "</p>";
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adoption Request | DogShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<main class="container mt-4">
    <h1 class="text-center">Adoption Request Form</h1>
    <br />
    <br />
    <br />
    <form action="adoption-form.php" method="post">
        <div class="row">
            <div class="col-md-4">
                <div class="mb-3">
                    <label for="dogId" class="form-label"><strong>Dog</strong><br />If you forgot the name of dog you wish to adopt, <a href="doglist.php" target="_blank">click here</a> to see the list again.</label>
                    <select class="form-control" id="dogId" name="dogId" style="width: 100%;" required>
                        <?php while ($dog = mysqli_fetch_assoc($dogs)): ?>
                            <option value="<?= $dog['DogID'] ?>"><?= htmlspecialchars($dog['DogName']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label class="form-label"><strong>Have you had pets in the past?</strong></label>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="hadPastPets" id="hadPastPetsYes" value="yes" required>
                        <label class="form-check-label" for="hadPastPetsYes">
                            Yes
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="hadPastPets" id="hadPastPetsNo" value="no" required>
                        <label class="form-check-label" for="hadPastPetsNo">
                            No
                        </label>
                    </div>
                </div>
            </div>
            <div id="petsInfo" class="col-md-4" style="display: none;">
                <div class="mb-3">
                    <label class="form-label"><strong>Was any of those pets a dog?</strong></label>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="hadDog" id="hadDogYes" value="yes">
                        <label class="form-check-label" for="hadDogYes">
                            Yes
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="hadDog" id="hadDogNo" value="no">
                        <label class="form-check-label" for="hadDogNo">
                            No
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="mb-3">
                    <label for="annualIncome" class="form-label"><strong>Annual Income</strong></label>
                    <input type="number" class="form-control" id="annualIncome" name="annualIncome" min="0" required>
                </div>
            </div>
            <div class="col-md-4">
                <div class="mb-3">
                    <label for="numPets" class="form-label"><strong>Number of Pets</strong></label>
                    <input type="number" class="form-control" id="numPets" name="numPets" min="0" required>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <label for="historyNote" class="form-label"><strong>Case for Adoption</strong></label>
            <textarea class="form-control" id="historyNote" name="historyNote" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit Request</button>
        <button type="reset" class="btn btn-secondary">Reset</button>
    </form>
</main>

<?php include 'footer.php'; // Include the footer ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Show/hide the "Was any of those pets a dog?" question based on the selection of the first question
    document.querySelectorAll('input[name="hadPastPets"]').forEach(function(radio) {
        radio.addEventListener('change', function() {
            var petsInfo = document.getElementById('petsInfo');
            var hadDogYes = document.getElementById('hadDogYes');
            var hadDogNo = document.getElementById('hadDogNo');

            if (this.value === 'yes') {
                petsInfo.style.display = 'block';
                hadDogYes.required = true;
                hadDogNo.required = true;
            } else {
                petsInfo.style.display = 'none';
                hadDogYes.required = false;
                hadDogNo.required = false;
            }
        });
    });
</script>
</body>
</html>
