<?php
// Start the session
session_start();
include 'db.php';  // Make sure db.php path is correct and contains the database connection logic

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    echo strlen($password);
    $email = $_POST['email'];
    $address = $_POST['address'];
    $userType = $_POST['userType'];
    $annualIncome = $_POST['annualIncome'];
    $numberOfPets = $_POST['numberOfPets'];

    $sql = "INSERT INTO UserTable (Username, FirstName, LastName, Password, Email, Address, UserType, AnnualIncome, NumberOfPetsAtHome) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssii", $username, $firstName, $lastName, $password, $email, $address, $userType, $annualIncome, $numberOfPets);
    if ($stmt->execute()) {
        header("Location: login.php"); // Redirect to login page
        exit;
    } else {
        echo '<div class="alert alert-danger" role="alert">Registration failed: ' . $stmt->error . '</div>';
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form | Animal Adoption Center</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="password_validation.js"></script>

</head>
<body>
<?php
include 'header.php';
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h3 class="text-center">Registration</h3> 
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="firstName">First Name</label>
                            <input type="text" class="form-control" id="firstName" name="firstName" required>
                        </div>
                        <div class="form-group">
                            <label for="lastName">Last Name</label>
                            <input type="text" class="form-control" id="lastName" name="lastName" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="address">Address (house number, street, city state, zip)</label>
                            <input type="text" class="form-control" id="address" name="address" required>
                        </div>
                        <div class="form-group">
                            <label for="userType">User Type</label>
                            <select class="form-control" id="userType" name="userType">
                                <option value="" disabled selected>Select User Type</option>
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="annualIncome">Annual Income</label>
                            <input type="number" class="form-control" id="annualIncome" name="annualIncome" min="0">
                        </div>
                        <div class="form-group">
                            <label for="numberOfPets">Number of Pets at Home</label>
                            <input type="number" class="form-control" id="numberOfPets" name="numberOfPets" min="0">
                        </div>
                        <br />
                        <br />
                        <button type="submit" class="btn btn-primary">Register</button>
                        <button type="reset" class="btn btn-secondary btn-block">Reset</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
// Include the footer
include 'footer.php';
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
