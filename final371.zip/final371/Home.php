<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Welcome | M & K's Adoption House</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

?>

<!-- header.php -->
<?php
    include 'header.php';
?>

<main class="container mt-4">
    <h1 class="text-center mb-4 welcome-message"><strong>Welcome to M & K's Adoption House!</strong></h1>

    <div class="row">
        <div class="col-md-6 mb-3">
            <img src="images/dog1.jpeg" class="img-thumbnail" alt="sad gray dog sitting" />
        </div>
        <div class="col-md-6 mb-3">
            <img src="images/dog2.jpeg" class="img-thumbnail" alt="sad white dog laying on stomach" />
        </div>
    </div>
    <?php if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']): ?>
    <div class="text-center mb-4">
        <p>Imagine the joy of coming home to a furry friend who loves you unconditionally, just the way you are. At Doggie Shop, we believe in second chances and finding belonging in unexpected places. Adopting a dog isn't just about giving them a home; it's about finding your perfect match and creating a bond that fills your heart with love and acceptance.</p>
    </div>
    <?php endif; ?>
</main>

<?php
    include 'footer.php'; 
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
