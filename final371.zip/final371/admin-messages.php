<?php
session_start();
include 'db.php';

// Security check: Make sure the user is logged in and is an admin.
if (!isset($_SESSION['loggedin']) || $_SESSION['userType'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Get the list of messages
$messageList = $conn->query("SELECT * FROM MessageTabel");

// Handle form submission for sending messages
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["send_message"])) {
    $recipient = $_POST["recipient"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    // Send the email
    $headers = "From: Your Admin Email <admin@example.com>" . "\r\n";
    if (mail($recipient, $subject, $message, $headers)) {
        $success_message = "Message sent successfully!";
    } else {
        $error_message = "Failed to send message. Please try again later.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header class="navbar navbar-expand-lg navbar-light bg-primary">
    <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <!-- Navigation links -->
            </ul>
        </div>
    </div>
</header>
<div class="container mt-4">
    <h1>Messages</h1>
    <!-- Display message sending status -->
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success" role="alert">
            <?php echo $success_message; ?>
        </div>
    <?php elseif (isset($error_message)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo $error_message; ?>
        </div>
    <?php endif; ?>
    <!-- Form for sending messages -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="mb-3">
            <label for="recipient" class="form-label">Recipient Email</label>
            <input type="email" class="form-control" id="recipient" name="recipient" required>
        </div>
        <div class="mb-3">
            <label for="subject" class="form-label">Subject</label>
            <input type="text" class="form-control" id="subject" name="subject" required>
        </div>
        <div class="mb-3">
            <label for="message" class="form-label">Message</label>
            <textarea class="form-control" id="message" name="message" rows="3" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary" name="send_message">Send Message</button>
    </form>
    <!-- Display existing messages -->
    <table class="table">
        <!-- Message table -->
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
