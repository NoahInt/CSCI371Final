<?php
// Start the session
session_start();

// Include the header
include 'header.php';

// Include database connection file
require_once 'db.php'; // Ensure this points to your actual database connection file

// Define variables and initialize with empty values
$contactName = $contactEmail = $contactMessage = "";
$errorMessage = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty(trim($_POST["contactName"]))) {
        $errorMessage = "Please enter your name.";
    } else {
        $contactName = trim($_POST["contactName"]);
    }

    // Validate email
    if (empty(trim($_POST["contactEmail"]))) {
        $errorMessage = "Please enter your email.";
    } else {
        $contactEmail = trim($_POST["contactEmail"]);
    }

    // Validate message
    if (empty(trim($_POST["contactMessage"]))) {
        $errorMessage = "Please enter your message.";
    } else {
        $contactMessage = trim($_POST["contactMessage"]);
    }

    // Check input errors before inserting in database
    if (empty($errorMessage)) {
        // Prepare an insert statement
        $sql = "INSERT INTO ContactMessages (name, email, message) VALUES (?, ?, ?)";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sss", $param_name, $param_email, $param_message);

            // Set parameters
            $param_name = $contactName;
            $param_email = $contactEmail;
            $param_message = $contactMessage;

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Set a session variable to indicate success
                $_SESSION['message_sent'] = true;
                // Redirect to the same page to clear the form
                header("Location: contact.php");
                exit();
            } else {
                $errorMessage = "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Close connection
    mysqli_close($conn);
} else {
    // Check if the message was sent successfully and display the success message
    if (isset($_SESSION['message_sent']) && $_SESSION['message_sent']) {
        echo '<p class="alert alert-success">Thank you for your message. We will get back to you shortly.</p>';
        // Clear the session variable so it doesn't show the message upon subsequent accesses
        unset($_SESSION['message_sent']);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | DogShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<main class="container mt-4">
    <h1 class="text-center mb-4">Contact Us</h1>
    <section class="mb-5">
        <p>Have more questions? Email us and we can get to the bottom of it.</p>
        <form method="post" action="contact.php">
            <div class="row">
                <div class="col-md-5">
                    <div class="mb-3">
                        <label for="contactName" class="form-label">Name</label>
                        <input type="text" class="form-control" id="contactName" name="contactName" required value="<?= htmlspecialchars($contactName); ?>">
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="mb-3">
                        <label for="contactEmail" class="form-label">Email</label>
                        <input type="email" class="form-control" id="contactEmail" name="contactEmail" required value="<?= htmlspecialchars($contactEmail); ?>">
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label for="contactMessage" class="form-label">Message</label>
                <textarea class="form-control" id="contactMessage" name="contactMessage" rows="5" required><?= htmlspecialchars($contactMessage); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Send Message</button>
            <button type="reset" class="btn btn-primary">Reset</button>
        </form>
    </section>
    
    <div class="row">
        <section class="col-md-6 mb-5">
            <h2>Location</h2>
            <address>
                1234 Doggy Lane<br>
                Springfield, MO 09876<br>
                <abbr title="Phone">Phone:</abbr> (123) 456-7890
                <br>
               Email: <a href="mailto:csci371dogadoption@gmail.com">csci371dogadoption@gmail.com</a>
            </address>
        </section>
        
        <section class="col-md-6 mb-5">
            <h2>Hours of Operation</h2>
            <p>Monday - Friday: 6 AM to 6 PM</p>
            <p>Saturday: 12 AM to 6 PM</p>
            <p>Sunday: Closed</p>
        </section>
    </div>
</main>

<?php
// Include the footer
include 'footer.php';
?>

</body>
</html>
