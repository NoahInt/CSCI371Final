<?php
// Start the session
session_start();

// Include the header
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | DogShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Custom styling */
        .about-image {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<main class="container mt-4">
    <h1 class="text-center mb-4">About Dog Adoption at Doggie Shop</h1>
    
    <section class="mb-5">
        <h2>Our Vision</h2>
        <p>
            At M & K's Adoption House, our vision is to redefine furry friend’s happiness and revolutionize the dog-human connection. We're on a quest to foster relationships that transcend the ordinary, creating a world where every wag is a victory, and every bark is a beacon of hope. Through innovative adoption strategies and unparalleled care, we're rewriting the story of every dog's journey to joy.
        </p>
    </section>
    
    <section class="mb-5">
        <h2>Reasons to Adopt a Dog </h2>
        <p>
            Thinking about bringing a furry friend into your life? At M & K's Adoption House, we prioritize quality over quantity, ensuring each of our four-legged companions receives personalized care and attention. From health check-ups to behavioral training, our dedicated volunteers work tirelessly to prepare our dogs for their forever homes. By choosing to adopt with us, you're not just welcoming a new furry family member; you're providing a loving home to a dog who's been given the best chance for a happy, fulfilling life.
        </p>
    </section>
    
    <section class="mb-5">
        <h2>Come Visit Us </h2>
        <p>
            Ready to meet your new best friend? Swing by M & K's Adoption House at 123 Main Street, Fargo, ND 58102. Our doors are open, and our furry friends are waiting to greet you with wagging tails and slobbery kisses. Whether you're looking for a playful pup or a cuddly companion, we've got the perfect match just waiting to steal your heart.
        </p>
    </section>

    <div class="row">
        <div class="col-md-6">
            <img src="images/aboutPic.jpeg" class="img-thumbnail about-image" alt="Owner with his adopted dog" />
        </div>
        <div class="col-md-6">
            <img src="images/aboutPic2.jpeg" class="img-thumbnail about-image" alt="Owner with his adopted dog" />
        </div>
    </div>
</main>

<?php
// Include the footer
include 'footer.php';
?>

</body>
</html>
