<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

?>

<!-- header.php -->
<nav class="navbar navbar-expand-lg navbar-light bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand" href="Home.php">
            <img src="images/logo.jpeg" alt="doglogo" width="80" height="60">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link text-uppercase" href="Home.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-uppercase" href="contact.php">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-uppercase" href="about.php">About</a>
                </li>
                <?php if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']): ?>
                    <li class="nav-item">
                        <a class="nav-link text-uppercase" href="doglist.php">Dog List</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-uppercase" href="adoption-form.php">Adoption</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">LOGOUT</a>
                    </li>
                    <li class="nav-item">
                        <span class="navbar-text text-uppercase">
                            Logged in as <?= htmlspecialchars($_SESSION['username']); ?>
                        </span>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link text-uppercase" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-uppercase" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
